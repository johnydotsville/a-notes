import { Person } from "./person"

console.log("Hello, typescript!");

const person = new Person();
person.hello();