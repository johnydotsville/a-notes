export class Person {
  hello() {
    console.log("Hello, world!");
  }
}