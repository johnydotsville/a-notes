const message = "Hello, typescript!";
console.log(message);