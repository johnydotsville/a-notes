function App() {
  return (
    <div>
      Пустое react-приложение.
    </div>
  );
}

export default App;
