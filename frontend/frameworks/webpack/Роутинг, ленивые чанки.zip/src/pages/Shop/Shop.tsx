import React from "react";

const Shop = () => {
  return (
    <h1>
      Магазин
    </h1>
  )
}

export default Shop;