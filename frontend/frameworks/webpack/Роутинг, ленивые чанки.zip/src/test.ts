export function calc(a: number, b: number): number {
  return a + b;
}