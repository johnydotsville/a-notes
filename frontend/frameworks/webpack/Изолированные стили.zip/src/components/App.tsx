import React from "react";
import * as classes from "./App.module.scss";

export const App = () => {
  return (
    <div>
      <p className={classes.nicep}>Hello, world!</p>
    </div>
  )
}