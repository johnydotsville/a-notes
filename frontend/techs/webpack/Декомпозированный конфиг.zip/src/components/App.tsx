import React from "react";
import "./App.scss";

export const App = () => {
  return (
    <div>
      <p>Hello, world!</p>
    </div>
  )
}