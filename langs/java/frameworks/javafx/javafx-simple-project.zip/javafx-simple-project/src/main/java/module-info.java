module johny.dotsville {
    requires javafx.controls;
    exports johny.dotsville;
}
